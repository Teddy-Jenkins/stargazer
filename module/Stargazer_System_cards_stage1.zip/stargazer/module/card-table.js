/**
 * Stargazer Card Table — Stage 1
 *
 * Scope of this stage:
 *  - A dedicated canvas layer ("stargazerCards") that renders Card documents
 *    living in a single world Pile ("Table") as draggable PIXI objects.
 *  - Cards can be face-up or face-down (click to flip, GM only for now).
 *  - Position (x/y/rotation) is stored on the Card document itself via flags,
 *    so it persists in the world database and is NOT scene-scoped — cards
 *    stick around across scene changes, exactly like the design doc calls for.
 *  - Dragging updates the Card document, which Foundry syncs to all clients
 *    automatically (no custom socket needed for this part — updateDocument
 *    broadcasts natively).
 *  - A GM-only "Deal Test Cards" scene control creates a deck (if missing),
 *    draws a few cards into the Table pile, and gives them scattered
 *    positions so there's something to drag immediately.
 *
 * NOT in this stage (later stages): hand tray UI, stacking/sorting,
 * pass-to-player, deck shuffle/discard UI, standalone card creation UI,
 * color tagging.
 */

const MODULE_NS = "stargazer";
const TABLE_PILE_FLAG = "isCardTable";
const POS_FLAG_KEY = "cardPos"; // { x, y, rotation, faceUp }

// ── Card sprite dimensions (canvas px, independent of grid size) ───────────
const CARD_WIDTH = 140;
const CARD_HEIGHT = 196;

export class CardTableLayer extends InteractionLayer {

  static get layerOptions() {
    return foundry.utils.mergeObject(super.layerOptions, {
      name: "stargazerCards",
      zIndex: 290, // above tiles/tokens-ish; tune later if it fights other layers
    });
  }

  /** Map of Card.id -> PIXI.Container currently rendered on this layer */
  cardSprites = new Map();

  /** The world Pile (Cards document) representing the physical table */
  get tablePile() {
    return game.cards?.find(c => c.getFlag(MODULE_NS, TABLE_PILE_FLAG));
  }

  async _draw() {
    await super._draw();
    this.cardSprites.forEach(c => c.destroy({ children: true }));
    this.cardSprites.clear();

    const pile = this.tablePile;
    if (!pile) return;

    for (const card of pile.cards) {
      this._renderCard(card);
    }
  }

  /** Create (or recreate) the PIXI representation of a single Card document */
  _renderCard(card) {
    this.cardSprites.get(card.id)?.destroy({ children: true });

    const pos = card.getFlag(MODULE_NS, POS_FLAG_KEY) || { x: 100, y: 100, rotation: 0, faceUp: false };

    const container = new PIXI.Container();
    container.x = pos.x;
    container.y = pos.y;
    container.rotation = pos.rotation || 0;
    container.cardId = card.id;
    container.eventMode = "static";
    container.cursor = "pointer";

    const bg = new PIXI.Graphics();
    const faceUp = !!pos.faceUp;
    bg.beginFill(faceUp ? 0xf5f0e6 : 0x2a2a3a, 1);
    bg.lineStyle(2, faceUp ? 0x8a7a5a : 0x6a6a8a, 1);
    bg.drawRoundedRect(-CARD_WIDTH / 2, -CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT, 10);
    bg.endFill();
    container.addChild(bg);

    const label = new PIXI.Text(faceUp ? (card.name || "Card") : "🂠", {
      fontFamily: "Roboto, sans-serif",
      fontSize: faceUp ? 16 : 42,
      fill: faceUp ? 0x222222 : 0xcccccc,
      align: "center",
      wordWrap: true,
      wordWrapWidth: CARD_WIDTH - 16,
    });
    label.anchor.set(0.5);
    container.addChild(label);

    if (faceUp && card.description) {
      const desc = new PIXI.Text(card.description, {
        fontFamily: "Roboto, sans-serif",
        fontSize: 11,
        fill: 0x444444,
        align: "center",
        wordWrap: true,
        wordWrapWidth: CARD_WIDTH - 16,
      });
      desc.anchor.set(0.5);
      desc.y = 30;
      container.addChild(desc);
    }

    this._wireDrag(container, card);

    container.on("rightclick", async (ev) => {
      ev.stopPropagation();
      await this._flipCard(card);
    });

    this.addChild(container);
    this.cardSprites.set(card.id, container);
  }

  /** Drag handling — works for any client; permission check happens before persisting */
  _wireDrag(container, card) {
    let dragging = false;
    let dragData = null;

    container.on("pointerdown", (ev) => {
      ev.stopPropagation();
      dragging = true;
      const local = ev.getLocalPosition(this);
      dragData = { offsetX: container.x - local.x, offsetY: container.y - local.y };
      container.alpha = 0.85;
      canvas.stage.on("pointermove", onMove);
      canvas.stage.once("pointerup", onUp);
      canvas.stage.once("pointerupoutside", onUp);
    });

    const onMove = (ev) => {
      if (!dragging) return;
      const local = ev.getLocalPosition(this);
      container.x = local.x + dragData.offsetX;
      container.y = local.y + dragData.offsetY;
    };

    const onUp = async () => {
      dragging = false;
      container.alpha = 1;
      canvas.stage.off("pointermove", onMove);
      await this._persistPosition(card, { x: container.x, y: container.y });
    };
  }

  async _persistPosition(card, { x, y }) {
    const current = card.getFlag(MODULE_NS, POS_FLAG_KEY) || {};
    await card.setFlag(MODULE_NS, POS_FLAG_KEY, { ...current, x, y });
  }

  async _flipCard(card) {
    const current = card.getFlag(MODULE_NS, POS_FLAG_KEY) || {};
    await card.setFlag(MODULE_NS, POS_FLAG_KEY, { ...current, faceUp: !current.faceUp });
  }

  /** Re-render a single card when its document updates (called from the updateCard hook) */
  refreshCard(card) {
    if (!this.tablePile || card.parent?.id !== this.tablePile.id) return;
    this._renderCard(card);
  }

  /** Remove a card's sprite (called from deleteCard hook) */
  removeCard(cardId) {
    this.cardSprites.get(cardId)?.destroy({ children: true });
    this.cardSprites.delete(cardId);
  }
}

// ── Setup: register layer, hooks, scene control button ─────────────────────

export function initCardTable() {

  // Register the layer with Foundry's canvas (v14 object-based layer registration)
  Hooks.once("init", () => {
    CONFIG.Canvas.layers.stargazerCards = {
      layerClass: CardTableLayer,
      group: "interface",
    };
  });

  Hooks.on("canvasReady", () => {
    canvas.stargazerCards?.draw();
  });

  // Live updates: a card moved/flipped by anyone re-renders for everyone
  Hooks.on("updateCard", (card) => {
    canvas.stargazerCards?.refreshCard(card);
  });

  Hooks.on("createCard", (card) => {
    if (card.parent?.id === canvas.stargazerCards?.tablePile?.id) {
      canvas.stargazerCards?._renderCard(card);
    }
  });

  Hooks.on("deleteCard", (card) => {
    canvas.stargazerCards?.removeCard(card.id);
  });

  // GM scene control: bootstrap a test deck + table pile, deal a few cards
  Hooks.on("getSceneControlButtons", (controls) => {
    if (!game.user.isGM) return;
    if (!controls.tokens?.tools) return;
    controls.tokens.tools.dealTestCards = {
      name: "dealTestCards",
      title: "Deal Test Cards (Stage 1 demo)",
      icon: "fa-solid fa-cards",
      order: Object.keys(controls.tokens.tools).length,
      button: true,
      visible: true,
      onChange: () => dealTestCards(),
    };
  });
}

/** GM-only bootstrap: ensure a Table pile exists, ensure a demo deck exists, draw a few cards onto the table at scattered positions */
async function dealTestCards() {
  if (!game.user.isGM) return ui.notifications.warn("Only the GM can deal test cards.");

  let pile = game.cards.find(c => c.getFlag(MODULE_NS, TABLE_PILE_FLAG));
  if (!pile) {
    pile = await Cards.create({
      name: "Table",
      type: "pile",
      flags: { [MODULE_NS]: { [TABLE_PILE_FLAG]: true } },
    });
  }

  let deck = game.cards.find(c => c.type === "deck" && c.getFlag(MODULE_NS, "isDemoDeck"));
  if (!deck) {
    deck = await Cards.create({
      name: "Demo Deck",
      type: "deck",
      flags: { [MODULE_NS]: { isDemoDeck: true } },
    });
    const demoCards = ["Harm", "Friction", "Loss", "Fatigue", "Threat"].map((n, i) => ({
      name: n,
      description: `Demo card: ${n}`,
      faces: [{ name: n, img: "icons/svg/card-joker.svg" }],
      face: 0,
      back: { name: "Card Back", img: "icons/svg/card-hand.svg" },
      sort: i,
    }));
    await deck.createEmbeddedDocuments("Card", demoCards);
  }

  // Draw 3 fresh cards from the deck into the Table pile (if deck has cards left)
  const drawCount = Math.min(3, deck.availableCards.length);
  if (drawCount === 0) {
    return ui.notifications.info("Demo deck is empty — recall it from the Cards sidebar to reset.");
  }
  const drawn = await deck.deal([pile], drawCount, { how: 0 });

  // Scatter the newly drawn cards near the center of the current view
  const center = { x: canvas.stage.pivot.x || 1000, y: canvas.stage.pivot.y || 1000 };
  for (const cardsArr of drawn) {
    for (const cardData of cardsArr) {
      const card = pile.cards.get(cardData.id ?? cardData._id);
      if (!card) continue;
      await card.setFlag(MODULE_NS, POS_FLAG_KEY, {
        x: center.x + (Math.random() - 0.5) * 300,
        y: center.y + (Math.random() - 0.5) * 300,
        rotation: (Math.random() - 0.5) * 0.3,
        faceUp: false,
      });
    }
  }

  ui.notifications.info(`Dealt ${drawCount} card(s) to the table.`);
}
